<!DOCTYPE html>
<html>
<head>
  <title>Report - Number of Tuples in Works Relation</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }

    h2 {
      margin-bottom: 10px;
    }

    p {
      margin-top: 0;
    }
  </style>
</head>
<body>
  <h2>Report - Number of Tuples in Works Relation</h2>
  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "emp";

  // Create a new connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check the connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  // Query to get the number of tuples in the works relation
  $sql = "SELECT COUNT(*) AS tuple_count FROM works";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
      // Fetch the result as an associative array
      $row = $result->fetch_assoc();
      $tuple_count = $row["tuple_count"];

      // Display the tuple count
      echo "<p>Number of tuples: " . $tuple_count . "</p>";
  } else {
      echo "<p>No results found.</p>";
  }

  // Close the connection
  $conn->close();
  ?>
</body>
</html>
