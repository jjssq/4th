<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emp";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind the INSERT statement
$stmt = $conn->prepare("INSERT INTO employee (employee_name, street, city) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $employee_name, $street, $city);

// Get values from the form submission
$employee_name = $_POST["employee_name"];
$street = $_POST["street"];
$city = $_POST["city"];

// Execute the prepared statement
if ($stmt->execute() === TRUE) {
    echo "Record added successfully.";
} else {
    echo "Error adding record: " . $conn->error;
}

// Close the prepared statement and connection
$stmt->close();
$conn->close();
?>
