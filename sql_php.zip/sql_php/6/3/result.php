<!DOCTYPE html>
<html>
<head>
  <title>Report - Employees in EMP</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }

    h2 {
      margin-bottom: 10px;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      margin-bottom: 5px;
    }
  </style>
</head>
<body>
  <h2>Report - Employees in EMP</h2>

  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "emp";

  // Create a new connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check the connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  // Query to find all employees who earn more than each employee of Trust Bank
  $sql = "SELECT *
          FROM employee";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
      echo "<ul>";
      while ($row = $result->fetch_assoc()) {
          echo "<li>" . $row["employee_name"] . "</li>";
      }
      echo "</ul>";
  } else {
      echo "<p>No employees found.</p>";
  }

  // Close the connection
  $conn->close();
  ?>
</body>
</html>
