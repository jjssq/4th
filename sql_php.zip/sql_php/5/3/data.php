<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bank";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

require_once('data.php');
try {
    if (isset($_POST['customer_name']) && isset($_POST['customer_street']) && isset($_POST['customer_city'])) {
        $customer_name = $_POST['customer_name'];
        $customer_street = $_POST['customer_street'];
        $customer_city = $_POST['customer_city'];

        $sql = "INSERT INTO customer (customer_name, customer_street, customer_city)
                VALUES ('$customer_name', '$customer_street', '$customer_city')";

        if (mysqli_query($conn, $sql)) {
            echo "New customer record created successfully";
            http_response_code(200);
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            http_response_code(500);
        }

    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        http_response_code(400);
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    http_response_code(500);
}

mysqli_close($conn);

?>
