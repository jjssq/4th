<!DOCTYPE html>
<html>
<head>
    <title>Customer Table</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: grid;
            place-items: center;
            height: 80vh;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
			margin-top: 0px;
        }

        .container {
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            padding: 20px;
        }

        table {
            width: 400px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #e9e9e9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Customer Table</h1>
        <table>
            <tr>
                <th>Name</th>
                <th>Street</th>
                <th>City</th>
            </tr>

            <?php
                // Database credentials
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "bank";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch data from customers table
                $sql = "SELECT * FROM customer";
                $result = $conn->query($sql);

                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["customer_name"] . "</td>";
                    echo "<td>" . $row["customer_street"] . "</td>";
                    echo "<td>" . $row["customer_city"] . "</td>";
                    echo "</tr>";
                }

                // Close database connection
                $conn->close();
            ?>
        </table>
    </div>
</body>
</html>
