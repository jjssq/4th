<!DOCTYPE html>
<html>

<head>
  <title>Registration Form</title>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      document.getElementById('registration-form').addEventListener('submit', function(event) {
        event.preventDefault();

        // Perform form submission via JavaScript
        var formData = new FormData(this);

        fetch(this.action, {
            method: this.method,
            body: formData
          })
          .then(function(response) {
            if (response.ok && response.status >= 200 && response.status <= 299) {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Registration successful!'
              });

              // Redirect after 2 seconds
              setTimeout(function() {
                window.location.href = 'result.php';
              }, 2000);
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Registration failed!'
              });
            }
          })
          .catch(function(error) {
            console.log('Error:', error);
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Registration failed!'
            });
          });
      });
    });
  </script>
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 80vh;
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }

    .container {
      width: 400px;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      border-radius: 5px;
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    input[type="text"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    button[type="submit"] {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      border: none;
      color: #fff;
      text-align: center;
      cursor: pointer;
      border-radius: 4px;
      font-weight: bold;
    }

    button[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Registration Form</h1>
    <form id="registration-form" action="data.php" method="POST">
      <div class="form-group">
        <label for="customer_name">Name:</label>
        <input type="text" id="customer_name" name="customer_name" required>
      </div>
      <div class="form-group">
        <label for="customer_street">Street:</label>
        <input type="text" id="customer_street" name="customer_street" required>
      </div>
      <div class="form-group">
        <label for="customer_city">City:</label>
        <input type="text" id="customer_city" name="customer_city" required>
      </div>
      <button type="submit">Submit</button>
    </form>
  </div>
</body>

</html>
